import { NextResponse } from 'next/server';
import clientPromise from '@/lib/mongodb';
import { z } from 'zod';

const bookingRequestSchema = z.object({
  userId: z.string(),
  name: z.string(),
  email: z.string().email(),
  building: z.string(),
  apartmentType: z.string(),
  apartmentNumber: z.string(),
  services: z.string(),
  roomCounts: z.object({
    standard: z.number(),
    deep: z.number(),
    'move-out': z.number(),
  }),
  date: z.string(),
  time: z.string(),
});

/**
 * 🔐 POST — USER SENDS REQUEST (OTHER BUILDING)
 */
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const data = bookingRequestSchema.parse(body);

    const client = await clientPromise;
    const db = client.db();

    await db.collection('booking_requests').insertOne({
      ...data,
      status: 'Pending',
      createdAt: new Date(),
    });

    return NextResponse.json(
      { message: 'Request sent to admin' },
      { status: 201 }
    );
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json(
        { message: 'Invalid data', errors: err.errors },
        { status: 400 }
      );
    }

    console.error('Booking request error:', err);
    return NextResponse.json(
      { message: 'Internal Server Error' },
      { status: 500 }
    );
  }
}

/**
 * 👑 GET — ADMIN FETCHES ALL OTHER-BUILDING REQUESTS
 */
export async function GET() {
  try {
        console.log('ADMIN GET booking_requests called');

    const client = await clientPromise;
    const db = client.db();

    const requests = await db
      .collection('booking_requests')
      .find({})
      .sort({ createdAt: -1 })
      .toArray();

    return NextResponse.json(requests, { status: 200 });
  } catch (err) {
    console.error('Fetch booking requests error:', err);
    return NextResponse.json(
      { message: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
