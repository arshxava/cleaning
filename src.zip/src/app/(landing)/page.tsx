'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Building,
  Mail,
  Home,
  Phone,
  User,
  MessageSquare,
  Lock
} from 'lucide-react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { useRouter } from 'next/navigation';

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useEffect, useState } from 'react';

const formSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters.'),
  email: z.string().email('Invalid email address.'),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
  phone: z.string().min(10, 'Phone number must be at least 10 digits.'),
  notifyByEmail: z.boolean().optional(),
  school: z.string().min(1, 'Please select or enter your school.'),
  roomSize: z.string().min(1, 'Please select or enter your room size.'), // ✅ works for both
});

type BuildingData = {
  _id: string;
  name: string;
  roomTypes: { name: string }[];
};

export default function SignUpPage() {
  const { toast } = useToast();
  const router = useRouter();

  const [buildings, setBuildings] = useState<BuildingData[]>([]);
  const [selectedBuilding, setSelectedBuilding] = useState<BuildingData | null>(null);
  const [isOtherBuilding, setIsOtherBuilding] = useState(false); // ✅

  useEffect(() => {
    const fetchBuildings = async () => {
      try {
        const response = await fetch('/api/buildings');
        if (response.ok) {
          const data = await response.json();
          setBuildings(data);
        }
      } catch {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: 'Could not load building data.',
        });
      }
    };
    fetchBuildings();
  }, [toast]);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      email: '',
      password: '',
      phone: '',
      notifyByEmail: false,
    },
  });

  const handleBuildingChange = (buildingName: string) => {
    if (buildingName === 'OTHER') {
      setIsOtherBuilding(true);
      setSelectedBuilding(null);
      form.setValue('school', '');
      form.setValue('roomSize', '');
      return;
    }

    setIsOtherBuilding(false);
    const building = buildings.find(b => b.name === buildingName);
    setSelectedBuilding(building || null);
    form.setValue('school', building?.name || '');
    form.resetField('roomSize');
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        values.email,
        values.password
      );

      const profileResponse = await fetch('/api/users/ensure-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: userCredential.user.uid,
          name: values.name,
          email: values.email,
          password: values.password,
          phone: values.phone,
          notifyByEmail: values.notifyByEmail === false,
          school: values.school,
          roomSize: values.roomSize,
          role: 'user',
        }),
      });

      if (!profileResponse.ok) throw new Error('Failed to save user profile.');

      toast({
        title: 'Account Created Successfully!',
        description: "Welcome! You're now logged in.",
      });

      router.push('/dashboard');

    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Sign Up Failed',
        description: error.message,
      });
    }
  }

  return (
     <div className="flex items-center justify-center py-12">
      <div className="mx-auto grid w-[350px] gap-6">
        <div className="grid gap-2 text-center">
          <h1 className="text-3xl font-bold font-headline">Get Started</h1>
          <p className="text-balance text-muted-foreground">
            Create your account to schedule your first cleaning.
          </p>
        </div>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4">

            {/* NAME */}
            <FormField control={form.control} name="name" render={({ field }) => (
              <FormItem>
                <FormLabel>Full Name</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            {/* EMAIL */}
            <FormField control={form.control} name="email" render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input type="email" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            {/* PASSWORD */}
            <FormField control={form.control} name="password" render={({ field }) => (
              <FormItem>
                <FormLabel>Password</FormLabel>
                <FormControl>
                  <Input type="password" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            {/* PHONE */}
            <FormField control={form.control} name="phone" render={({ field }) => (
              <FormItem>
                <FormLabel>Phone</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            {/* BUILDING */}
            <FormField control={form.control} name="school" render={() => (
              <FormItem>
                <FormLabel>Building Name</FormLabel>
                <Select onValueChange={handleBuildingChange}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select building" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {buildings.map(b => (
                      <SelectItem key={b._id} value={b.name}>{b.name}</SelectItem>
                    ))}
                    <SelectItem value="OTHER">Other</SelectItem>
                  </SelectContent>
                </Select>

                {isOtherBuilding && (
                  <FormControl className="mt-2">
                    <Input
                      placeholder="Enter building name"
                      {...form.register('school')}
                    />
                  </FormControl>
                )}

                <FormMessage />
              </FormItem>
            )} />

            {/* ROOM SIZE */}
            {!isOtherBuilding ? (
              <FormField control={form.control} name="roomSize" render={({ field }) => (
                <FormItem>
                  <FormLabel>Room Size</FormLabel>
                  <Select onValueChange={field.onChange} disabled={!selectedBuilding}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select building first" />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedBuilding?.roomTypes.map((room, i) => (
                        <SelectItem key={i} value={room.name}>{room.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
            ) : (
              <FormField control={form.control} name="roomSize" render={({ field }) => (
                <FormItem>
                  <FormLabel>Room Size</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter room size" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            )}

            <Button type="submit" className="w-full">Create Account</Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
