import { config } from 'dotenv';
config();

import '@/ai/flows/complaint-response-time-analyzer.ts';